import {
    search_bar, 
    search_button, 
    marvel_container,
    showLoading, 
    displayMarvelContent,
    filter_buttons
} from "./html_elements.js";

// Configuración de Marvel API
const MARVEL_API = {
    apikey: "8faf53a98e0a8bf276698dfb51b208f9",
    ts: "1",
    hash: "b8b4fbf645a05264a11ff56a156f5c2c",
    baseUrl: "https://gateway.marvel.com/v1/public"
};

let currentContentType = 'comics'; // Por defecto cómics

// Función equivalente a check_weather pero para Marvel
async function loadMarvelContent(searchTerm = '', contentType = 'comics') {
    showLoading();
    
    const params = new URLSearchParams({
        apikey: MARVEL_API.apikey,
        ts: MARVEL_API.ts,
        hash: MARVEL_API.hash,
        limit: 20
    });
    
    // Agregar búsqueda específica según el tipo
    if (searchTerm && searchTerm.trim()) {
        if (contentType === 'comics') {
            params.append('titleStartsWith', searchTerm.trim());
        } else {
            params.append('nameStartsWith', searchTerm.trim());
        }
    }
    
    const url = `${MARVEL_API.baseUrl}/${contentType}?${params.toString()}`;
    
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Error ${response.status}`);
        
        const data = await response.json();
        const results = data.data.results || [];
        
        displayMarvelContent(results, contentType.slice(0, -1)); // quitar 's'
        return results;
    } catch (error) {
        console.error('Error cargando contenido Marvel:', error);
        // Datos de respaldo
        const fallbackData = getFallbackMarvelData(contentType);
        displayMarvelContent(fallbackData, contentType.slice(0, -1));
        return fallbackData;
    }
}

// Función para obtener datos de respaldo
function getFallbackMarvelData(type) {
    if (type === 'comics') {
        return [
            {
                title: "Amazing Spider-Man #1",
                thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/6/80/5269608c1be7a", extension: "jpg" },
                urls: [{ url: "https://www.marvel.com/comics/issue/6482/amazing_spider-man_1963_1" }],
                description: "La primera aparición del Sorprendente Hombre Araña."
            },
            {
                title: "X-Men #1",
                thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/f/c0/5261a85b2814e", extension: "jpg" },
                urls: [{ url: "https://www.marvel.com/comics/issue/12413/uncanny_x-men_1963_1" }],
                description: "El debut de los mutantes más famosos del mundo."
            }
        ];
    } else {
        return [
            {
                name: "Spider-Man",
                thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/3/50/526548a343e4b", extension: "jpg" },
                urls: [{ url: "https://www.marvel.com/characters/spider-man-peter-parker" }],
                description: "Friendly neighborhood Spider-Man"
            },
            {
                name: "Iron Man",
                thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/9/c0/527bb7b37ff55", extension: "jpg" },
                urls: [{ url: "https://www.marvel.com/characters/iron-man-tony-stark" }],
                description: "Genius, billionaire, playboy, philanthropist"
            }
        ];
    }
}

// Cargar contenido inicial por defecto
await loadMarvelContent('', currentContentType)

search_button.addEventListener('click', async() => {
    const searchTerm = search_bar.value.trim();
    
    if (searchTerm) {
        console.info(`🔍 Buscando: "${searchTerm}" en ${currentContentType}`);
        await loadMarvelContent(searchTerm, currentContentType);
    } else {
        // Si está vacío, cargar contenido inicial
        await loadMarvelContent('', currentContentType);
    }
    
    // No limpiar el campo para que el usuario vea lo que buscó
    // search_bar.value = '';
});

let debounceTimer;

// Búsqueda en tiempo real con debounce (equivalente a tu búsqueda de clima)
search_bar.addEventListener('input', async() => {
    clearTimeout(debounceTimer);
    const searching = search_bar.value.trim();

    if (searching === '') {
        search_bar.classList.remove("searching");
        // Cargar contenido por defecto cuando esté vacío
        await loadMarvelContent('', currentContentType);
        return;
    }

    // Agregar clase visual de búsqueda
    search_bar.classList.add("searching");

    debounceTimer = setTimeout(async() => {
        console.info(`🔍 Búsqueda automática para: "${searching}" en ${currentContentType}`);
        
        try {
            const results = await loadMarvelContent(searching, currentContentType);
            
            // Log de resultados (equivalente a tu console.info(data))
            console.info(`✅ Encontrados ${results.length} resultados:`, results);
            
            if (results.length === 0) {
                console.info("❌ No hay coincidencias para esta búsqueda");
            }
            
        } catch (error) {
            console.error("❌ Error en búsqueda automática:", error);
        } finally {
            search_bar.classList.remove("searching");
        }
        
    }, 500); // 500ms de delay (un poco más que tus 350ms para evitar spam a la API)
});

// Manejar tecla Enter
search_bar.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        search_button.click();
    }
});

// Configurar filtros (equivalente a cambiar ubicación en tu app de clima)
if (filter_buttons) {
    filter_buttons.forEach(button => {
        button.addEventListener('click', async (e) => {
            // Actualizar botones activos
            filter_buttons.forEach(btn => btn.classList.remove('active'));
            e.target.classList.add('active');
            
            // Cambiar tipo de contenido
            const newType = e.target.getAttribute('data-filter');
            if (newType !== currentContentType) {
                currentContentType = newType;
                console.info(`🎛️ Filtro cambiado a: ${currentContentType}`);
                
                // Recargar contenido con el nuevo filtro
                const currentSearch = search_bar.value.trim();
                await loadMarvelContent(currentSearch, currentContentType);
            }
        });
    });
}

// Función para obtener sugerencias rápidas (equivalente a tu autocomplete)
async function getMarvelSuggestions(query, type = 'comics') {
    if (!query || query.length < 2) return [];
    
    const params = new URLSearchParams({
        apikey: MARVEL_API.apikey,
        ts: MARVEL_API.ts,
        hash: MARVEL_API.hash,
        limit: 5 // Solo 5 sugerencias
    });
    
    if (type === 'comics') {
        params.append('titleStartsWith', query);
    } else {
        params.append('nameStartsWith', query);
    }
    
    try {
        const response = await fetch(`${MARVEL_API.baseUrl}/${type}?${params.toString()}`);
        if (!response.ok) return [];
        
        const data = await response.json();
        return data.data.results || [];
    } catch (error) {
        console.error('Error obteniendo sugerencias:', error);
        return [];
    }
}

// Función para obtener contenido aleatorio
async function getRandomContent() {
    console.info('🎲 Función getRandomContent ejecutada!');
    console.info('🎲 Obteniendo contenido aleatorio...');
    showLoading();
    
    // Decidir aleatoriamente entre comics o characters
    const randomTypes = ['comics', 'characters'];
    const randomType = randomTypes[Math.floor(Math.random() * randomTypes.length)];
    
    // Generar offset aleatorio para obtener contenido diferente
    const randomOffset = Math.floor(Math.random() * 1000);
    
    const params = new URLSearchParams({
        apikey: MARVEL_API.apikey,
        ts: MARVEL_API.ts,
        hash: MARVEL_API.hash,
        limit: 12, // Mostrar 12 elementos aleatorios
        offset: randomOffset.toString()
    });
    
    const url = `${MARVEL_API.baseUrl}/${randomType}?${params.toString()}`;
    
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Error ${response.status}`);
        
        const data = await response.json();
        const results = data.data.results || [];
        
        console.info(`🎲 Contenido aleatorio obtenido: ${results.length} ${randomType}`);
        
        // Mostrar contenido con indicador de que es aleatorio
        displayMarvelContent(results, randomType.slice(0, -1), true); // true = es contenido aleatorio
        
        // Actualizar el filtro activo visualmente
        if (filter_buttons) {
            filter_buttons.forEach(btn => btn.classList.remove('active'));
            const targetButton = Array.from(filter_buttons).find(btn => 
                btn.getAttribute('data-filter') === randomType
            );
            if (targetButton) {
                targetButton.classList.add('active');
            }
        }
        
        // Actualizar tipo de contenido actual
        currentContentType = randomType;
        
        return results;
    } catch (error) {
        console.error('Error obteniendo contenido aleatorio:', error);
        
        // Datos de respaldo aleatorios
        const fallbackTypes = ['comics', 'characters'];
        const fallbackType = fallbackTypes[Math.floor(Math.random() * fallbackTypes.length)];
        const fallbackData = getFallbackMarvelData(fallbackType);
        
        // Mezclar aleatoriamente los datos de respaldo
        const shuffledFallback = fallbackData.sort(() => 0.5 - Math.random());
        
        console.info(`🎲 Usando datos de respaldo aleatorios: ${fallbackType}`);
        displayMarvelContent(shuffledFallback, fallbackType.slice(0, -1), true);
        
        return shuffledFallback;
    }
}

// Inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', async () => {
    console.info('🚀 Marvel App inicializada');
    console.info(`📚 Contenido inicial: ${currentContentType}`);
    
    // Asegurar que el filtro correcto esté activo
    if (filter_buttons) {
        filter_buttons.forEach(btn => {
            if (btn.getAttribute('data-filter') === currentContentType) {
                btn.classList.add('active');
            }
        });
    }
    
    // Configurar el botón random
    const randomButton = document.querySelector('#random-btn');
    if (randomButton) {
        randomButton.addEventListener('click', getRandomContent);
        console.info('🎲 Botón Random configurado');
    } else {
        console.warn('❌ Botón Random no encontrado');
    }
});

// Hacer la función getRandomContent disponible globalmente
window.getRandomContent = getRandomContent;
// Elementos HTML para la aplicación de Marvel
const search_bar = document.getElementById("search-bar");
const search_button = document.getElementById("search-button");
const marvel_container = document.getElementById("marvel-row");
const loading_indicator = document.getElementById("loading-indicator");
const error_container = document.getElementById("error-container");
const hero_count = document.getElementById("hero-count");
const filter_buttons = document.querySelectorAll(".filter-btn");
const suggestions = document.getElementById("suggestions"); // Para futuro autocompletado visual

// Función para mostrar carga
function showLoading() {
    if (marvel_container) {
        marvel_container.innerHTML = '<div class="col-12 text-center"><p class="text-primary">🔍 Buscando héroes de Marvel...</p></div>';
    }
}

// Función para mostrar error
function showError(message) {
    if (marvel_container) {
        marvel_container.innerHTML = `
            <div class="col-12">
                <div class="alert alert-danger">
                    <h4>❌ Error</h4>
                    <p>${message}</p>
                </div>
            </div>`;
    }
}

// Función para mostrar héroes/cómics
function displayMarvelContent(items, type = 'hero', isRandom = false) {
    if (!marvel_container) return;
    
    let contentHTML = '';
    
    // Agregar banner de contenido aleatorio si aplica
    if (isRandom) {
        const randomLabel = type === 'comic' ? 'Cómics' : 'Héroes';
        contentHTML += `
            <div class="col-12 mb-3">
                <div class="alert alert-success text-center">
                    <h5 class="mb-2"><i class="fas fa-dice"></i> Contenido Aleatorio</h5>
                    <p class="mb-0">¡Descubre ${randomLabel} aleatorios de Marvel! <button class="btn btn-sm btn-outline-success ml-2" onclick="getRandomContent()"><i class="fas fa-sync-alt"></i> Otro Random</button></p>
                </div>
            </div>`;
    }
    
    if (items && items.length > 0) {
        for (const item of items) {
            const title = item.name || item.title || 'Sin título';
            const url = (item.urls && item.urls.length > 0) ? item.urls[0].url : '#';
            const thumbnail = item.thumbnail ? `${item.thumbnail.path}.${item.thumbnail.extension}` : 'https://via.placeholder.com/300x400?text=No+Image';
            const description = item.description ? item.description.substring(0, 100) + '...' : 'Sin descripción disponible';
            
            contentHTML += `
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="card h-100 shadow-sm marvel-card">
                        <a href="${url}" target="_blank" class="text-decoration-none">
                            <img src="${thumbnail}" alt="${title}" class="card-img-top img-thumbnail">
                        </a>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-danger font-weight-bold">${title}</h5>
                            <p class="card-text flex-grow-1">${description}</p>
                        </div>
                    </div>
                </div>`;
        }
        
        // Actualizar contador si existe
        if (hero_count) {
            const typeLabel = type === 'comic' ? 'cómics' : 'héroes';
            hero_count.textContent = `${items.length} ${typeLabel} encontrados`;
        }
        
    } else {
        const typeLabel = type === 'comic' ? 'cómics' : 'héroes';
        contentHTML = `
            <div class="col-12">
                <div class="alert alert-warning text-center">
                    <h4>🔍 No se encontraron resultados</h4>
                    <p>No hay ${typeLabel} disponibles para esta búsqueda.</p>
                    <p class="mb-0"><small class="text-muted">Intenta con otros términos de búsqueda</small></p>
                </div>
            </div>`;
            
        // Actualizar contador
        if (hero_count) {
            hero_count.textContent = `0 ${typeLabel} encontrados`;
        }
    }
    
    marvel_container.innerHTML = contentHTML;
}

// Función para limpiar búsqueda
function clearSearch() {
    if (search_bar) {
        search_bar.value = '';
    }
}

// Función para agregar evento de búsqueda
function setupSearchEvents(searchCallback) {
    if (search_button) {
        search_button.addEventListener('click', searchCallback);
    }
    
    if (search_bar) {
        search_bar.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchCallback();
            }
        });
    }
}

// Exportar elementos y funciones
export { 
    search_bar, 
    search_button, 
    marvel_container,
    loading_indicator,
    error_container,
    hero_count,
    filter_buttons,
    suggestions,
    showLoading, 
    showError, 
    displayMarvelContent,
    clearSearch,
    setupSearchEvents
};
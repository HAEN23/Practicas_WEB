
import { 
    showLoading, 
    showError, 
    displayMarvelContent,
    setupSearchEvents,
    search_bar,
    filter_buttons
} from '../script/html_elements.js';

const marvel = {
    currentType: 'comics', // 'comics' o 'characters'
    
    render: (retryAttempt = false, searchTerm = '') => {
        if (retryAttempt) {
            console.log('Reintentando conexión con la API de Marvel...');
        }
        // Configuración de la API de Marvel
        const apikey = "8faf53a98e0a8bf276698dfb51b208f9";
        const ts = "1";
        const hash = "b8b4fbf645a05264a11ff56a156f5c2c";
        
        // Request URL y parámetros según tu estructura (HTTPS es obligatorio)
        const baseUrl = `https://gateway.marvel.com/v1/public/${marvel.currentType}`;
        const params = {
            "apikey": apikey,
            "ts": ts, 
            "hash": hash,
            "limit": "12"
        };
        
        // Agregar término de búsqueda si existe
        if (searchTerm && searchTerm.trim()) {
            if (marvel.currentType === 'comics') {
                params.titleStartsWith = searchTerm.trim();
            } else {
                params.nameStartsWith = searchTerm.trim();
            }
        }
        
        // Construir URL con parámetros
        const urlParams = new URLSearchParams(params);
        const urlAPI = `${baseUrl}?${urlParams.toString()}`;

        // Mostrar indicador de carga
        showLoading();

        // Headers según tu estructura
        const headers = {
            'Accept': '*/*'
        };

        // Request Method: GET con fetch
        fetch(urlAPI, {
            method: 'GET',
            headers: headers
        })
            .then(res => {
                console.log('Response status:', res.status);
                if (!res.ok) {
                    throw new Error(`HTTPS error! status: ${res.status}`);
                }
                return res.json();
            })
            .then((json) => {
                console.log('API Response:', json);
                if (json.data && json.data.results && json.data.results.length > 0) {
                    // Usar la función del módulo para mostrar contenido
                    displayMarvelContent(json.data.results, marvel.currentType.slice(0, -1)); // quitar 's' del final
                } else {
                    displayMarvelContent([], marvel.currentType.slice(0, -1));
                }
            })
            .catch((error) => {
                console.error('Error fetching Marvel data:', error);
                
                // Datos de respaldo en caso de que la API falle
                const fallbackComics = [
                    {
                        title: "Amazing Spider-Man #1",
                        thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/6/80/5269608c1be7a", extension: "jpg" },
                        urls: [{ url: "https://www.marvel.com/comics/issue/6482/amazing_spider-man_1963_1" }],
                        description: "La primera aparición del Sorprendente Hombre Araña."
                    },
                    {
                        title: "X-Men #1", 
                        thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/f/c0/5261a85b2814e", extension: "jpg" },
                        urls: [{ url: "https://www.marvel.com/comics/issue/12413/uncanny_x-men_1963_1" }],
                        description: "El debut de los mutantes más famosos del mundo."
                    },
                    {
                        title: "Fantastic Four #1",
                        thumbnail: { path: "https://i.annihil.us/u/prod/marvel/i/mg/9/10/519baa6d1890a", extension: "jpg" },
                        urls: [{ url: "https://www.marvel.com/comics/issue/12894/fantastic_four_1961_1" }],
                        description: "La primera familia de superhéroes de Marvel."
                    }
                ];
                
                console.log('Usando datos de respaldo debido a error en API');
                // Mostrar mensaje de error y datos de respaldo
                const container = document.querySelector('#marvel-row');
                let contentHTML = `
                    <div class="col-12">
                        <div class="alert alert-warning">
                            <strong>⚠️ Modo offline:</strong> No se pudo conectar con la API de Marvel. Mostrando cómics de ejemplo.
                            <button class="btn btn-primary btn-sm ml-3" onclick="marvel.render(true)">
                                🔄 Reintentar conexión
                            </button>
                        </div>
                    </div>`;
                
                // Usar la función del módulo para mostrar datos de respaldo
                displayMarvelContent(fallbackComics, 'comic');
            });
    },
    
    // Función para manejar búsqueda
    search: () => {
        const searchTerm = search_bar ? search_bar.value : '';
        marvel.render(false, searchTerm);
    },
    
    // Función para cambiar filtro
    setFilter: (type) => {
        marvel.currentType = type;
        marvel.render();
    }
};

// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Configurar eventos de búsqueda
    setupSearchEvents(marvel.search);
    
    // Configurar eventos de filtros
    if (filter_buttons) {
        filter_buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                // Remover clase active de todos los botones
                filter_buttons.forEach(btn => btn.classList.remove('active'));
                // Agregar clase active al botón clickeado
                e.target.classList.add('active');
                // Cambiar el filtro
                const filterType = e.target.getAttribute('data-filter');
                marvel.setFilter(filterType);
            });
        });
    }
    
    // Cargar contenido inicial
    marvel.render();
});
    

import { Component, EventEmitter, Output } from '@angular/core';
import { SpotifyService } from '../../app/services/spotify.service';

@Component({
  selector: 'app-search-bar',
  standalone: false,
  templateUrl: './search-bar.html',
  styleUrl: './search-bar.css'
})
export class SearchBar {
  searchQuery: string = '';
  @Output() searchResults = new EventEmitter<any[]>();

  constructor(
    private spotifyService: SpotifyService
  ){}

  async doSearch(): Promise<void> {
    if (this.searchQuery.trim()) {
      try {
        const results = await this.spotifyService.searchTracks(this.searchQuery);
        console.log('🔍 Resultados de búsqueda:', results);
        this.searchResults.emit(results);
      } catch (error) {
        console.error('❌ Error en búsqueda:', error);
        this.searchResults.emit([]);
      }
    } else {
      this.searchResults.emit([]);
    }
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.doSearch();
    }
  }
} 
